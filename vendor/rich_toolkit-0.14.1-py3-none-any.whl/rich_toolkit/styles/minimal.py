from .base import BaseStyle


class MinimalStyle(BaseStyle):
    pass
